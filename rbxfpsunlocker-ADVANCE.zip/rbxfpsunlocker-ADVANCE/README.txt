RBXFPSUNLOCKER-ADVANCE is a tool used to enhance your gaming experience. 
It works by allowing you to increase the game's frame rate limit beyond the default limit of 60 frames per second to 120 144 160 165 and 240.
We are still working on 360hz. Other than that it should be better than the orignial rbxfpsunlocker as this has more RPU and HUI allowing it to bypass roblox fps cap rate.

           __                   ______                                           __                      __                           
          /  |                 /      \                                         /  |                    /  |                          
  ______  $$ |____   __    __ /$$$$$$  |  ______    _______  __    __  _______  $$ |  ______    _______ $$ |   __   ______    ______  
 /      \ $$      \ /  \  /  |$$ |_ $$/  /      \  /       |/  |  /  |/       \ $$ | /      \  /       |$$ |  /  | /      \  /      \ 
/$$$$$$  |$$$$$$$  |$$  \/$$/ $$   |    /$$$$$$  |/$$$$$$$/ $$ |  $$ |$$$$$$$  |$$ |/$$$$$$  |/$$$$$$$/ $$ |_/$$/ /$$$$$$  |/$$$$$$  |
$$ |  $$/ $$ |  $$ | $$  $$<  $$$$/     $$ |  $$ |$$      \ $$ |  $$ |$$ |  $$ |$$ |$$ |  $$ |$$ |      $$   $$<  $$    $$ |$$ |  $$/ 
$$ |      $$ |__$$ | /$$$$  \ $$ |      $$ |__$$ | $$$$$$  |$$ \__$$ |$$ |  $$ |$$ |$$ \__$$ |$$ \_____ $$$$$$  \ $$$$$$$$/ $$ |      
$$ |      $$    $$/ /$$/ $$  |$$ |      $$    $$/ /     $$/ $$    $$/ $$ |  $$ |$$ |$$    $$/ $$       |$$ | $$  |$$       |$$ |      
$$/       $$$$$$$/  $$/   $$/ $$/       $$$$$$$/  $$$$$$$/   $$$$$$/  $$/   $$/ $$/  $$$$$$/   $$$$$$$/ $$/   $$/  $$$$$$$/ $$/       
                                        $$ |                                                                                          
                                        $$ |                                                                                          
                                        $$/                                                                                                                                                                                                                                                                                                       